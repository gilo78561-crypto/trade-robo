import { useEffect, useRef } from "react";

export default function CandleChart({ candles, signal, height = 200, title = "" }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    if (!candles || candles.length === 0 || !canvasRef.current) return;
    draw();
  }, [candles, signal]);

  function draw() {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    const w = canvas.width;
    const h = canvas.height;

    // Colors
    const BG = "#0a0a0f";
    const GRID = "#1a1a2e";
    const UP = "#00c853";
    const DOWN = "#ff1744";
    const WICK_UP = "#00c853";
    const WICK_DOWN = "#ff1744";
    const TEXT = "#8888aa";
    const ENTRY = "#00bfff";
    const SL = "#ff1744";
    const TP = "#00c853";
    const OB = "rgba(30, 80, 200, 0.25)";
    const FVG = "rgba(200, 160, 0, 0.18)";

    ctx.fillStyle = BG;
    ctx.fillRect(0, 0, w, h);

    const data = candles.slice(-60);
    const pad = { left: 10, right: 70, top: 10, bottom: 22 };
    const cw = (w - pad.left - pad.right) / data.length;

    const highs = data.map((c) => c.high);
    const lows = data.map((c) => c.low);
    let maxP = Math.max(...highs);
    let minP = Math.min(...lows);

    // Include signal levels in range
    if (signal) {
      maxP = Math.max(maxP, signal.stop_loss || 0, signal.take_profit || 0, signal.entry_price || 0);
      minP = Math.min(minP, signal.stop_loss || Infinity, signal.take_profit || Infinity, signal.entry_price || Infinity);
    }

    const priceRange = maxP - minP;
    const margin = priceRange * 0.08;
    const high = maxP + margin;
    const low = minP - margin;
    const range = high - low;

    function px(price) {
      return pad.top + ((high - price) / range) * (h - pad.top - pad.bottom);
    }

    // Grid lines
    const gridLines = 5;
    for (let i = 0; i <= gridLines; i++) {
      const y = pad.top + (i / gridLines) * (h - pad.top - pad.bottom);
      const price = high - (i / gridLines) * range;
      ctx.strokeStyle = GRID;
      ctx.lineWidth = 0.5;
      ctx.beginPath();
      ctx.moveTo(pad.left, y);
      ctx.lineTo(w - pad.right, y);
      ctx.stroke();
      ctx.fillStyle = TEXT;
      ctx.font = "9px monospace";
      ctx.textAlign = "left";
      ctx.fillText(price.toFixed(price < 10 ? 4 : price < 1000 ? 2 : 0), w - pad.right + 4, y + 3);
    }

    // OB zone
    if (signal?.analysis?.order_block_high && signal?.analysis?.order_block_low) {
      ctx.fillStyle = OB;
      const y1 = px(signal.analysis.order_block_high);
      const y2 = px(signal.analysis.order_block_low);
      ctx.fillRect(pad.left, Math.min(y1, y2), w - pad.left - pad.right, Math.abs(y2 - y1));
      ctx.strokeStyle = "#1e50c8";
      ctx.lineWidth = 0.8;
      ctx.setLineDash([3, 3]);
      ctx.strokeRect(pad.left, Math.min(y1, y2), w - pad.left - pad.right, Math.abs(y2 - y1));
      ctx.setLineDash([]);
    }

    // FVG zone
    if (signal?.analysis?.fvg_start && signal?.analysis?.fvg_end) {
      ctx.fillStyle = FVG;
      const y1 = px(signal.analysis.fvg_end);
      const y2 = px(signal.analysis.fvg_start);
      ctx.fillRect(pad.left, Math.min(y1, y2), w - pad.left - pad.right, Math.abs(y2 - y1));
    }

    // Candles
    data.forEach((c, i) => {
      const x = pad.left + i * cw + cw * 0.1;
      const bw = cw * 0.8;
      const isBull = c.close >= c.open;
      const color = isBull ? UP : DOWN;

      ctx.strokeStyle = isBull ? WICK_UP : WICK_DOWN;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x + bw / 2, px(c.high));
      ctx.lineTo(x + bw / 2, px(c.low));
      ctx.stroke();

      const bodyTop = px(Math.max(c.open, c.close));
      const bodyBottom = px(Math.min(c.open, c.close));
      const bodyH = Math.max(1, bodyBottom - bodyTop);

      ctx.fillStyle = color;
      ctx.fillRect(x, bodyTop, bw, bodyH);
    });

    // Signal levels
    if (signal) {
      const drawLevel = (price, color, label, dashed = false) => {
        if (!price) return;
        const y = px(price);
        ctx.strokeStyle = color;
        ctx.lineWidth = 1.5;
        if (dashed) ctx.setLineDash([5, 4]);
        ctx.beginPath();
        ctx.moveTo(pad.left, y);
        ctx.lineTo(w - pad.right, y);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = color;
        ctx.font = "bold 9px monospace";
        ctx.textAlign = "left";
        ctx.fillText(`${label}: ${price?.toFixed?.(price < 10 ? 4 : price < 1000 ? 2 : 0)}`, w - pad.right + 4, y + 3);
      };

      drawLevel(signal.entry_price, ENTRY, "ENT");
      drawLevel(signal.stop_loss, SL, "SL", true);
      drawLevel(signal.take_profit, TP, "TP", true);
    }

    // Title
    if (title) {
      ctx.fillStyle = "#aaaacc";
      ctx.font = "bold 10px monospace";
      ctx.textAlign = "left";
      ctx.fillText(title, pad.left + 4, pad.top + 11);
    }

    // Last candle timestamp
    if (data.length > 0) {
      const last = data[data.length - 1];
      const d = new Date(last.timestamp);
      ctx.fillStyle = TEXT;
      ctx.font = "8px monospace";
      ctx.textAlign = "right";
      ctx.fillText(d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }), w - pad.right - 2, h - 6);
    }
  }

  return (
    <canvas
      ref={canvasRef}
      width={600}
      height={height}
      style={{ width: "100%", height: height, borderRadius: 4, display: "block" }}
    />
  );
}
