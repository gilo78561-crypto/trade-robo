import { useState, useEffect } from "react";
import CandleChart from "../components/CandleChart";
import { DataService } from "../services/DataService";

export default function SignalDetail({ signal, onBack, onUpdateResult }) {
  const [candles, setCandles] = useState(null);
  const isBuy = signal.direction === "BUY";
  const a = signal.analysis || {};

  useEffect(() => {
    DataService.fetchAllTimeframes(signal.symbol)
      .then((d) => setCandles(d))
      .catch(() => {});
  }, [signal.symbol]);

  const handleResult = (result) => {
    onUpdateResult(signal.id, result);
    onBack();
  };

  return (
    <div className="detail-page">
      <div className="detail-header">
        <button className="back-btn" onClick={onBack}>← RETOUR</button>
        <div className="detail-title">
          <span className="asset-badge lg">{signal.symbol}</span>
          <span className={`dir-badge lg ${isBuy ? "buy" : "sell"}`}>{signal.direction}</span>
          <span className="detail-time">
            {new Date(signal.created_at).toLocaleString("fr-FR")}
          </span>
        </div>
        <div className="detail-conf">
          <span className="conf-label">CONFIANCE</span>
          <div className="conf-meter">
            <div className="conf-fill" style={{ width: `${signal.confidence}%` }}></div>
          </div>
          <span className="conf-value">{signal.confidence}%</span>
        </div>
      </div>

      <div className="detail-grid">
        {/* Prices */}
        <div className="detail-card prices-card">
          <div className="card-title">NIVEAUX DE PRIX</div>
          <div className="price-block">
            <div className="price-item main">
              <span className="pi-label">ENTRÉE</span>
              <span className="pi-value entry">{signal.entry_price}</span>
            </div>
            <div className="price-item">
              <span className="pi-label">STOP LOSS</span>
              <span className="pi-value sl">{signal.stop_loss}</span>
              <span className="pi-diff">
                {Math.abs(((signal.entry_price - signal.stop_loss) / signal.entry_price) * 100).toFixed(3)}%
              </span>
            </div>
            <div className="price-item">
              <span className="pi-label">TAKE PROFIT</span>
              <span className="pi-value tp">{signal.take_profit}</span>
              <span className="pi-diff">
                +{Math.abs(((signal.take_profit - signal.entry_price) / signal.entry_price) * 100).toFixed(3)}%
              </span>
            </div>
            <div className="rr-block">
              <span className="rr-label">RATIO R:R</span>
              <span className="rr-value">{signal.risk_reward}:1</span>
            </div>
          </div>
        </div>

        {/* Analysis */}
        <div className="detail-card analysis-card">
          <div className="card-title">ANALYSE SMC/ICT</div>
          <div className="analysis-grid">
            <AnalysisRow label="Biais HTF" value={a.htf_bias?.toUpperCase()} cls={a.htf_bias === "bullish" ? "ok" : "ko"} detail={a.htf_reason} />
            <AnalysisRow label="Liquidité" value={a.liquidity_type || "-"} cls="ok" detail={a.liquidity_level ? `Niveau: ${a.liquidity_level?.toFixed?.(5)}` : ""} />
            <AnalysisRow label="CHOCH" value={a.choch_detected ? "DÉTECTÉ" : "NON"} cls={a.choch_detected ? "ok" : "ko"} detail={a.choch_level ? `Cassure: ${a.choch_level?.toFixed?.(5)}` : ""} />
            <AnalysisRow label="BOS H1" value={a.bos_detected ? "DÉTECTÉ" : "NON"} cls={a.bos_detected ? "ok" : "neutral"} detail={a.bos_level ? `Niveau: ${a.bos_level?.toFixed?.(5)}` : ""} />
            <AnalysisRow label="Order Block" value={a.order_block_high ? "IDENTIFIÉ" : "NON"} cls={a.order_block_high ? "ok" : "ko"} detail={a.order_block_high ? `${a.order_block_low?.toFixed?.(4)} — ${a.order_block_high?.toFixed?.(4)}` : ""} />
            <AnalysisRow label="FVG" value={a.fvg_start ? "IDENTIFIÉ" : "NON"} cls={a.fvg_start ? "ok" : "neutral"} detail={a.fvg_start ? `${a.fvg_start?.toFixed?.(4)} — ${a.fvg_end?.toFixed?.(4)}` : ""} />
            <AnalysisRow label="Zone Fib" value={a.fib_zone || "-"} cls={a.fib_pct < 50 ? "ok" : "neutral"} detail={a.fib_pct ? `Position: ${a.fib_pct}%` : ""} />
          </div>
        </div>

        {/* Chart M5 */}
        <div className="detail-card chart-card">
          <div className="card-title">GRAPHIQUE M5 — SETUP</div>
          <CandleChart
            candles={candles?.m5 || DataService.generateDemoCandles(signal.symbol, "m5")}
            signal={signal}
            height={220}
            title="M5"
          />
        </div>

        {/* Chart M15 */}
        <div className="detail-card chart-card">
          <div className="card-title">GRAPHIQUE M15 — CONTEXTE</div>
          <CandleChart
            candles={candles?.m15 || DataService.generateDemoCandles(signal.symbol, "m15")}
            signal={signal}
            height={180}
            title="M15"
          />
        </div>

        {/* Confluences */}
        <div className="detail-card confluences-card">
          <div className="card-title">CONFLUENCES</div>
          <div className="confluences-list">
            {(a.confluences || []).map((c, i) => (
              <div key={i} className={`confluence-item ${c.startsWith("✓") ? "ok" : "warn"}`}>
                {c}
              </div>
            ))}
          </div>
          <div className="justification">
            <div className="just-title">JUSTIFICATION COMPLÈTE</div>
            <p>{a.reason || "Analyse automatique SMC/ICT multi-timeframes."}</p>
          </div>
        </div>

        {/* Result */}
        {!signal.result && (
          <div className="detail-card result-card">
            <div className="card-title">ENREGISTRER RÉSULTAT</div>
            <div className="result-btns">
              <button className="btn-win" onClick={() => handleResult("win")}>✓ GAGNÉ (WIN)</button>
              <button className="btn-loss" onClick={() => handleResult("loss")}>✗ PERDU (LOSS)</button>
              <button className="btn-cancel" onClick={() => handleResult("cancelled")}>○ ANNULÉ</button>
            </div>
          </div>
        )}
        {signal.result && (
          <div className="detail-card result-card">
            <div className="card-title">RÉSULTAT</div>
            <div className={`result-display result-${signal.result}`}>
              {signal.result === "win" ? "✓ GAGNÉ" : signal.result === "loss" ? "✗ PERDU" : "○ ANNULÉ"}
            </div>
            {signal.closed_at && (
              <div className="result-time">
                Clôturé: {new Date(signal.closed_at).toLocaleString("fr-FR")}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function AnalysisRow({ label, value, cls, detail }) {
  return (
    <div className="ar-row">
      <span className="ar-label">{label}</span>
      <div className="ar-right">
        <span className={`ar-value ${cls}`}>{value}</span>
        {detail && <span className="ar-detail">{detail}</span>}
      </div>
    </div>
  );
}
