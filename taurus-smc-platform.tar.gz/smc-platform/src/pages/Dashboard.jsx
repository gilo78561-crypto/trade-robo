import { useMemo } from "react";
import CandleChart from "../components/CandleChart";

function SignalCard({ signal, onClick }) {
  const isBuy = signal.direction === "BUY";
  const statusLabel = signal.result === "win" ? "WIN" : signal.result === "loss" ? "LOSS" : "ACTIF";
  const statusClass = signal.result === "win" ? "status-win" : signal.result === "loss" ? "status-loss" : "status-active";

  return (
    <div className={`signal-card ${isBuy ? "buy" : "sell"}`} onClick={() => onClick(signal)}>
      <div className="sc-header">
        <div className="sc-asset">
          <span className="asset-badge">{signal.symbol}</span>
          <span className={`dir-badge ${isBuy ? "buy" : "sell"}`}>{signal.direction}</span>
        </div>
        <div className="sc-right">
          <span className={`status-badge ${statusClass}`}>{statusLabel}</span>
          <span className="confidence-badge">
            <span className="conf-bar" style={{ width: `${signal.confidence}%` }}></span>
            {signal.confidence}%
          </span>
        </div>
      </div>

      <div className="sc-prices">
        <div className="price-row">
          <span className="price-label">ENTRÉE</span>
          <span className="price-val entry">{signal.entry_price}</span>
        </div>
        <div className="price-row">
          <span className="price-label">SL</span>
          <span className="price-val sl">{signal.stop_loss}</span>
        </div>
        <div className="price-row">
          <span className="price-label">TP</span>
          <span className="price-val tp">{signal.take_profit}</span>
        </div>
        <div className="price-row">
          <span className="price-label">RR</span>
          <span className="price-val rr">{signal.risk_reward}:1</span>
        </div>
      </div>

      <div className="sc-footer">
        <span className="sc-tf">{signal.timeframe}</span>
        <span className="sc-time">
          {new Date(signal.created_at).toLocaleString("fr-FR", {
            day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit",
          })}
        </span>
        <span className="sc-details">DÉTAILS →</span>
      </div>
    </div>
  );
}

function AssetPanel({ symbol, liveData }) {
  const data = liveData?.[symbol];
  const candles = data?.m5 || [];
  const lastCandle = candles[candles.length - 1];
  const prevCandle = candles[candles.length - 2];
  const change = lastCandle && prevCandle
    ? ((lastCandle.close - prevCandle.close) / prevCandle.close * 100).toFixed(3)
    : null;
  const isUp = change > 0;

  const labelMap = { XAUUSD: "Or (XAU/USD)", BTCUSD: "Bitcoin (BTC/USD)", EURUSD: "Euro (EUR/USD)" };
  const isDemo = candles.length > 0 && candles[candles.length - 1]?.isDemo;

  return (
    <div className="asset-panel">
      <div className="ap-header">
        <div>
          <span className="ap-symbol">{symbol}</span>
          <span className="ap-name">{labelMap[symbol]}</span>
          {isDemo && <span className="demo-badge">DEMO</span>}
        </div>
        <div className="ap-price-block">
          {lastCandle && (
            <>
              <span className="ap-price">
                {lastCandle.close.toLocaleString("fr-FR", { maximumFractionDigits: symbol === "EURUSD" ? 5 : 2 })}
              </span>
              {change !== null && (
                <span className={`ap-change ${isUp ? "up" : "down"}`}>
                  {isUp ? "▲" : "▼"} {Math.abs(change)}%
                </span>
              )}
            </>
          )}
        </div>
      </div>
      <CandleChart candles={candles} height={130} title="M5" />
    </div>
  );
}

export default function Dashboard({ signals, liveData, onSignalClick, isAnalyzing, analysisLog, runAnalysis }) {
  const activeSignals = useMemo(
    () => signals.filter((s) => s.status === "active" || !s.result).slice(0, 20),
    [signals]
  );

  const stats = useMemo(() => {
    const closed = signals.filter((s) => s.result);
    const wins = closed.filter((s) => s.result === "win").length;
    const wr = closed.length > 0 ? ((wins / closed.length) * 100).toFixed(0) : "-";
    const avgRR = closed.length > 0
      ? (closed.reduce((s, sig) => s + sig.risk_reward, 0) / closed.length).toFixed(2)
      : "-";
    return { total: signals.length, active: activeSignals.length, wr, avgRR, closed: closed.length };
  }, [signals, activeSignals]);

  return (
    <div className="dashboard">
      {/* Stats bar */}
      <div className="stats-bar">
        {[
          { label: "SIGNAUX TOTAUX", value: stats.total },
          { label: "ACTIFS", value: stats.active, cls: "accent-blue" },
          { label: "WIN RATE", value: stats.wr !== "-" ? `${stats.wr}%` : "-", cls: stats.wr >= 50 ? "accent-green" : "accent-red" },
          { label: "RR MOYEN", value: stats.avgRR !== "-" ? `${stats.avgRR}:1` : "-" },
          { label: "CLÔTURÉS", value: stats.closed },
        ].map((s) => (
          <div className="stat-card" key={s.label}>
            <span className="stat-label">{s.label}</span>
            <span className={`stat-value ${s.cls || ""}`}>{s.value}</span>
          </div>
        ))}
      </div>

      <div className="dashboard-grid">
        {/* Left: asset charts */}
        <div className="left-col">
          <div className="section-title">
            <span className="section-icon">◈</span> MARCHÉS EN TEMPS RÉEL
          </div>
          {["XAUUSD", "BTCUSD", "EURUSD"].map((sym) => (
            <AssetPanel key={sym} symbol={sym} liveData={liveData} />
          ))}
        </div>

        {/* Right: signals */}
        <div className="right-col">
          <div className="section-title">
            <span className="section-icon">⬡</span> SIGNAUX ACTIFS
            <span className="signal-count">{activeSignals.length}</span>
          </div>

          {activeSignals.length === 0 ? (
            <div className="empty-signals">
              <div className="empty-icon">◎</div>
              <p>Aucun signal actif</p>
              <p className="empty-sub">
                Le moteur analyse les marchés à chaque bougie M5.
                <br />
                Les signaux ne sont générés que si toutes les conditions SMC/ICT sont respectées.
              </p>
              <button className="btn-primary" onClick={runAnalysis} disabled={isAnalyzing}>
                {isAnalyzing ? "Analyse en cours..." : "↻ Forcer une analyse"}
              </button>
            </div>
          ) : (
            <div className="signals-list">
              {activeSignals.map((s) => (
                <SignalCard key={s.id} signal={s} onClick={onSignalClick} />
              ))}
            </div>
          )}

          {/* Analysis log */}
          <div className="section-title" style={{ marginTop: "1.5rem" }}>
            <span className="section-icon">▶</span> LOG D'ANALYSE
          </div>
          <div className="analysis-log">
            {analysisLog.length === 0 ? (
              <span className="log-empty">En attente de la première analyse...</span>
            ) : (
              analysisLog.slice(0, 30).map((line, i) => (
                <div
                  key={i}
                  className={`log-line ${
                    line.includes("🎯") ? "log-signal"
                    : line.includes("✓") ? "log-ok"
                    : line.includes("✗") ? "log-err"
                    : ""
                  }`}
                >
                  {line}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
