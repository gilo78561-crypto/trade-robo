# 🐂 TAURUS — Plateforme SMC/ICT Trading

Plateforme d'analyse de marché automatisée basée sur la stratégie SMC/ICT.

## 🚀 Déploiement rapide

### Option 1 — Local (développement)
```bash
npm install
npm run dev
# → Accès sur http://localhost:5173
```

### Option 2 — Build production
```bash
npm install
npm run build
# Le dossier dist/ est prêt à déployer
```

### Option 3 — Vercel (recommandé, gratuit)
```bash
npm install -g vercel
vercel
# Suivre les instructions → URL de production automatique
```

### Option 4 — Netlify
```bash
npm run build
# Glisser le dossier dist/ sur netlify.com/drop
```

## 📊 Sources de données

| Actif | Source | API |
|-------|--------|-----|
| BTC/USD | Binance | api.binance.com |
| XAU/USD | Yahoo Finance | via proxy |
| EUR/USD | Yahoo Finance | via proxy |

> En cas d'échec API, les données de démonstration sont utilisées automatiquement.

## 🔔 Notifications Telegram

1. Parlez à `@BotFather` sur Telegram
2. `/newbot` → donnez un nom → copiez le token
3. Parlez à `@userinfobot` pour obtenir votre Chat ID
4. Entrez les deux dans Paramètres → Notifications Telegram

## ⚙️ Configuration

Tous les paramètres sont accessibles depuis l'interface :
- Actifs analysés (XAU/USD, BTC/USD, EUR/USD)
- RR minimum (défaut: 2:1)
- Marge SL (défaut: 0.2%)
- Fréquence d'analyse (défaut: 5 min)
- Direction BUY/SELL

## 🧠 Logique SMC/ICT

Le moteur valide séquentiellement :
1. **Biais HTF H4** — HH+HL ou BOS haussier/baissier
2. **Liquidité** — Sweep des equal lows/highs
3. **CHOCH M15** — Cassure du dernier LH ou HL
4. **BOS H1** — Confirmation de structure
5. **Order Block** — Dernière bougie opposée avant impulsion
6. **FVG** — Fair Value Gap non mitigé
7. **Zone Fibonacci** — Discount (<50%) ou Premium (>50%)
8. **Validation RR** — TP/risque ≥ minimum configuré

Aucun signal n'est émis si toutes les conditions ne sont pas remplies.

## 📁 Structure

```
src/
├── App.jsx               # Application principale
├── index.css             # Styles complets (thème taureau)
├── components/
│   ├── BullLogo.jsx      # Logo taureau SVG
│   └── CandleChart.jsx   # Graphique chandelier Canvas
├── pages/
│   ├── Dashboard.jsx     # Tableau de bord principal
│   ├── SignalDetail.jsx  # Détail d'un signal
│   ├── History.jsx       # Historique et statistiques
│   └── Settings.jsx      # Configuration
└── services/
    ├── DataService.js    # Fetch données réelles (Binance/Yahoo)
    ├── SMCEngine.js      # Moteur d'analyse SMC/ICT
    ├── StorageService.js # Persistance localStorage
    └── NotificationService.js # Alertes Telegram
```

## ⚠️ Avertissement

Outil d'aide à la décision uniquement. Ne constitue pas un conseil financier.
