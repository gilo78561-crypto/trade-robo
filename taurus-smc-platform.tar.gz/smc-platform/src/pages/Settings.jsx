import { useState } from "react";

export default function Settings({ settings, onSave }) {
  const [form, setForm] = useState({ ...settings });
  const [saved, setSaved] = useState(false);

  const update = (key, value) => setForm((f) => ({ ...f, [key]: value }));
  const updateAsset = (asset, val) =>
    setForm((f) => ({ ...f, enabledAssets: { ...f.enabledAssets, [asset]: val } }));

  const handleSave = () => {
    onSave(form);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="settings-page">
      <div className="settings-header">
        <span className="section-icon">⚙</span>
        <h1>PARAMÈTRES</h1>
      </div>

      <div className="settings-grid">
        {/* Assets */}
        <div className="settings-card">
          <div className="card-title">MARCHÉS ANALYSÉS</div>
          {[
            { id: "XAUUSD", label: "XAU/USD — Or" },
            { id: "BTCUSD", label: "BTC/USD — Bitcoin" },
            { id: "EURUSD", label: "EUR/USD — Euro" },
          ].map(({ id, label }) => (
            <div className="toggle-row" key={id}>
              <span className="toggle-label">{label}</span>
              <label className="toggle">
                <input
                  type="checkbox"
                  checked={form.enabledAssets?.[id] !== false}
                  onChange={(e) => updateAsset(id, e.target.checked)}
                />
                <span className="toggle-slider"></span>
              </label>
            </div>
          ))}
        </div>

        {/* Signal direction */}
        <div className="settings-card">
          <div className="card-title">DIRECTION DES SIGNAUX</div>
          <div className="toggle-row">
            <span className="toggle-label">Signaux BUY activés</span>
            <label className="toggle">
              <input
                type="checkbox"
                checked={form.enableBuy !== false}
                onChange={(e) => update("enableBuy", e.target.checked)}
              />
              <span className="toggle-slider buy"></span>
            </label>
          </div>
          <div className="toggle-row">
            <span className="toggle-label">Signaux SELL activés</span>
            <label className="toggle">
              <input
                type="checkbox"
                checked={form.enableSell !== false}
                onChange={(e) => update("enableSell", e.target.checked)}
              />
              <span className="toggle-slider sell"></span>
            </label>
          </div>
        </div>

        {/* RR & SL */}
        <div className="settings-card">
          <div className="card-title">GESTION DU RISQUE</div>
          <div className="field-row">
            <label className="field-label">RR minimum</label>
            <div className="field-input-group">
              <input
                type="number"
                min="1" max="10" step="0.5"
                value={form.minRR}
                onChange={(e) => update("minRR", parseFloat(e.target.value))}
                className="settings-input"
              />
              <span className="field-unit">: 1</span>
            </div>
          </div>
          <div className="field-row">
            <label className="field-label">Marge SL (%)</label>
            <div className="field-input-group">
              <input
                type="number"
                min="0.1" max="0.5" step="0.05"
                value={(form.slMargin * 100).toFixed(2)}
                onChange={(e) => update("slMargin", parseFloat(e.target.value) / 100)}
                className="settings-input"
              />
              <span className="field-unit">%</span>
            </div>
          </div>
          <div className="field-row">
            <label className="field-label">Fréquence analyse</label>
            <div className="field-input-group">
              <input
                type="number"
                min="1" max="60" step="1"
                value={form.analysisFrequency}
                onChange={(e) => update("analysisFrequency", parseInt(e.target.value))}
                className="settings-input"
              />
              <span className="field-unit">min</span>
            </div>
          </div>
        </div>

        {/* Telegram */}
        <div className="settings-card">
          <div className="card-title">NOTIFICATIONS TELEGRAM</div>
          <div className="telegram-info">
            <p>Pour activer les alertes Telegram :</p>
            <ol>
              <li>Créez un bot via <code>@BotFather</code></li>
              <li>Copiez le token</li>
              <li>Obtenez votre Chat ID via <code>@userinfobot</code></li>
            </ol>
          </div>
          <div className="field-row">
            <label className="field-label">Bot Token</label>
            <input
              type="text"
              placeholder="123456789:ABC-DEF..."
              value={form.telegramToken || ""}
              onChange={(e) => update("telegramToken", e.target.value)}
              className="settings-input wide"
            />
          </div>
          <div className="field-row">
            <label className="field-label">Chat ID</label>
            <input
              type="text"
              placeholder="-100123456789"
              value={form.telegramChatId || ""}
              onChange={(e) => update("telegramChatId", e.target.value)}
              className="settings-input wide"
            />
          </div>
        </div>

        {/* About */}
        <div className="settings-card about-card">
          <div className="card-title">À PROPOS — STRATÉGIE SMC/ICT</div>
          <div className="about-content">
            <div className="about-step">
              <span className="step-num">1</span>
              <div><strong>Biais HTF (H4)</strong> — Higher High/Low ou BOS haussier/baissier</div>
            </div>
            <div className="about-step">
              <span className="step-num">2</span>
              <div><strong>Liquidité</strong> — Prise des equal lows/highs (sweep)</div>
            </div>
            <div className="about-step">
              <span className="step-num">3</span>
              <div><strong>CHOCH</strong> — Cassure du dernier Lower High ou Higher Low</div>
            </div>
            <div className="about-step">
              <span className="step-num">4</span>
              <div><strong>Order Block</strong> — Dernière bougie opposée avant l'impulsion</div>
            </div>
            <div className="about-step">
              <span className="step-num">5</span>
              <div><strong>FVG</strong> — Gap entre bougie 1 high et bougie 3 low</div>
            </div>
            <div className="about-step">
              <span className="step-num">6</span>
              <div><strong>Zone Fibonacci</strong> — Discount (BUY) / Premium (SELL)</div>
            </div>
            <div className="about-step">
              <span className="step-num">7</span>
              <div><strong>Validation RR</strong> — Minimum {form.minRR}:1 requis</div>
            </div>
          </div>
        </div>
      </div>

      <div className="settings-save">
        <button className={`btn-save ${saved ? "saved" : ""}`} onClick={handleSave}>
          {saved ? "✓ SAUVEGARDÉ" : "SAUVEGARDER LES PARAMÈTRES"}
        </button>
      </div>
    </div>
  );
}
