import { useState, useEffect, useCallback, useRef } from "react";
import Dashboard from "./pages/Dashboard";
import SignalDetail from "./pages/SignalDetail";
import History from "./pages/History";
import Settings from "./pages/Settings";
import { SMCEngine } from "./services/SMCEngine";
import { DataService } from "./services/DataService";
import { NotificationService } from "./services/NotificationService";
import { StorageService } from "./services/StorageService";
import BullLogo from "./components/BullLogo";

export default function App() {
  const [activePage, setActivePage] = useState("dashboard");
  const [selectedSignal, setSelectedSignal] = useState(null);
  const [signals, setSignals] = useState([]);
  const [liveData, setLiveData] = useState({});
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(null);
  const [settings, setSettings] = useState(StorageService.getSettings());
  const [analysisLog, setAnalysisLog] = useState([]);
  const engineRef = useRef(null);
  const intervalRef = useRef(null);

  useEffect(() => {
    const saved = StorageService.getSignals();
    setSignals(saved);
    runAnalysis();
    const freq = (settings.analysisFrequency || 5) * 60 * 1000;
    intervalRef.current = setInterval(runAnalysis, freq);
    return () => clearInterval(intervalRef.current);
  }, []);

  useEffect(() => {
    StorageService.saveSettings(settings);
    clearInterval(intervalRef.current);
    const freq = (settings.analysisFrequency || 5) * 60 * 1000;
    intervalRef.current = setInterval(runAnalysis, freq);
    return () => clearInterval(intervalRef.current);
  }, [settings]);

  const runAnalysis = useCallback(async () => {
    setIsAnalyzing(true);
    const log = [`[${new Date().toLocaleTimeString()}] Démarrage analyse...`];
    try {
      const assets = ["XAUUSD", "BTCUSD", "EURUSD"].filter(
        (a) => settings.enabledAssets?.[a] !== false
      );

      const newLiveData = {};
      for (const asset of assets) {
        log.push(`  ↳ Récupération données ${asset}...`);
        try {
          const data = await DataService.fetchAllTimeframes(asset);
          newLiveData[asset] = data;
          log.push(`  ✓ ${asset}: ${data.m5?.length || 0} bougies M5`);
        } catch (e) {
          log.push(`  ✗ ${asset}: ${e.message}`);
        }
      }
      setLiveData(newLiveData);

      const newSignals = [];
      for (const asset of assets) {
        if (!newLiveData[asset]) continue;
        log.push(`  → Analyse SMC/ICT ${asset}...`);
        try {
          const engine = new SMCEngine(newLiveData[asset], settings);
          const signal = engine.analyze(asset);
          if (signal) {
            log.push(`  🎯 SIGNAL ${signal.direction} détecté sur ${asset}!`);
            newSignals.push(signal);
            if (settings.telegramToken && settings.telegramChatId) {
              NotificationService.sendTelegram(signal, settings);
            }
          } else {
            log.push(`  ○ Pas de setup valide sur ${asset}`);
          }
        } catch (e) {
          log.push(`  ✗ Analyse ${asset}: ${e.message}`);
        }
      }

      if (newSignals.length > 0) {
        const all = StorageService.addSignals(newSignals);
        setSignals(all);
      }

      setLastUpdate(new Date());
      log.push(`[${new Date().toLocaleTimeString()}] Analyse terminée.`);
    } catch (e) {
      log.push(`ERREUR: ${e.message}`);
    }
    setAnalysisLog((prev) => [...log, ...prev].slice(0, 200));
    setIsAnalyzing(false);
  }, [settings]);

  const handleSignalClick = (signal) => {
    setSelectedSignal(signal);
    setActivePage("detail");
  };

  const handleCloseDetail = () => {
    setSelectedSignal(null);
    setActivePage("dashboard");
  };

  const updateSignalResult = (id, result) => {
    const updated = StorageService.updateSignalResult(id, result);
    setSignals(updated);
  };

  return (
    <div className="app-root">
      <header className="top-bar">
        <div className="top-bar-left">
          <BullLogo size={40} />
          <div className="brand-text">
            <span className="brand-name">TAURUS</span>
            <span className="brand-sub">SMC/ICT TRADING PLATFORM</span>
          </div>
        </div>
        <nav className="top-nav">
          {[
            { id: "dashboard", label: "DASHBOARD", icon: "⬡" },
            { id: "history", label: "HISTORIQUE", icon: "◈" },
            { id: "settings", label: "PARAMÈTRES", icon: "⚙" },
          ].map((item) => (
            <button
              key={item.id}
              className={`nav-btn ${activePage === item.id ? "active" : ""}`}
              onClick={() => setActivePage(item.id)}
            >
              <span className="nav-icon">{item.icon}</span>
              {item.label}
            </button>
          ))}
        </nav>
        <div className="top-bar-right">
          <div className={`status-pill ${isAnalyzing ? "analyzing" : "live"}`}>
            <span className="pulse-dot"></span>
            {isAnalyzing ? "ANALYSE EN COURS..." : "LIVE"}
          </div>
          {lastUpdate && (
            <span className="last-update">
              MAJ: {lastUpdate.toLocaleTimeString("fr-FR")}
            </span>
          )}
          <button
            className="refresh-btn"
            onClick={runAnalysis}
            disabled={isAnalyzing}
            title="Forcer une analyse"
          >
            ↻
          </button>
        </div>
      </header>

      <main className="main-content">
        {activePage === "dashboard" && (
          <Dashboard
            signals={signals}
            liveData={liveData}
            onSignalClick={handleSignalClick}
            isAnalyzing={isAnalyzing}
            analysisLog={analysisLog}
            runAnalysis={runAnalysis}
          />
        )}
        {activePage === "detail" && selectedSignal && (
          <SignalDetail
            signal={selectedSignal}
            onBack={handleCloseDetail}
            onUpdateResult={updateSignalResult}
          />
        )}
        {activePage === "history" && (
          <History
            signals={signals}
            onSignalClick={handleSignalClick}
          />
        )}
        {activePage === "settings" && (
          <Settings settings={settings} onSave={setSettings} />
        )}
      </main>

      <footer className="bottom-bar">
        <span>TAURUS SMC/ICT © {new Date().getFullYear()}</span>
        <span className="footer-sep">|</span>
        <span>Analyse automatique · Données temps réel</span>
        <span className="footer-sep">|</span>
        <span className="footer-warn">⚠ Outil d'aide à la décision uniquement</span>
      </footer>
    </div>
  );
}
