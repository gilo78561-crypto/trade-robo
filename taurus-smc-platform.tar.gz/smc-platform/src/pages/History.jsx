import { useMemo, useState } from "react";

export default function History({ signals, onSignalClick }) {
  const [filter, setFilter] = useState("all");
  const [assetFilter, setAssetFilter] = useState("all");

  const filtered = useMemo(() => {
    return signals.filter((s) => {
      const rf = filter === "all" || s.result === filter || (filter === "active" && !s.result);
      const af = assetFilter === "all" || s.symbol === assetFilter;
      return rf && af;
    });
  }, [signals, filter, assetFilter]);

  const stats = useMemo(() => {
    const closed = signals.filter((s) => s.result === "win" || s.result === "loss");
    const wins = closed.filter((s) => s.result === "win");
    const losses = closed.filter((s) => s.result === "loss");
    const wr = closed.length ? ((wins.length / closed.length) * 100).toFixed(1) : 0;
    const avgRR = closed.length ? (closed.reduce((s, x) => s + x.risk_reward, 0) / closed.length).toFixed(2) : 0;
    const profitFactor = losses.length
      ? ((wins.reduce((s, x) => s + x.risk_reward, 0)) / losses.length).toFixed(2)
      : wins.length > 0 ? "∞" : "-";
    return { wins: wins.length, losses: losses.length, wr, avgRR, profitFactor, total: closed.length };
  }, [signals]);

  return (
    <div className="history-page">
      <div className="history-stats">
        {[
          { label: "WIN RATE", value: `${stats.wr}%`, cls: stats.wr >= 50 ? "accent-green" : "accent-red" },
          { label: "VICTOIRES", value: stats.wins, cls: "accent-green" },
          { label: "DÉFAITES", value: stats.losses, cls: "accent-red" },
          { label: "PROFIT FACTOR", value: stats.profitFactor, cls: "accent-blue" },
          { label: "RR MOYEN", value: `${stats.avgRR}:1` },
          { label: "TOTAL CLÔTURÉS", value: stats.total },
        ].map((s) => (
          <div className="stat-card" key={s.label}>
            <span className="stat-label">{s.label}</span>
            <span className={`stat-value ${s.cls || ""}`}>{s.value}</span>
          </div>
        ))}
      </div>

      <div className="history-filters">
        <div className="filter-group">
          {["all", "active", "win", "loss", "cancelled"].map((f) => (
            <button
              key={f}
              className={`filter-btn ${filter === f ? "active" : ""}`}
              onClick={() => setFilter(f)}
            >
              {f === "all" ? "TOUS" : f === "active" ? "ACTIFS" : f.toUpperCase()}
            </button>
          ))}
        </div>
        <div className="filter-group">
          {["all", "XAUUSD", "BTCUSD", "EURUSD"].map((a) => (
            <button
              key={a}
              className={`filter-btn ${assetFilter === a ? "active" : ""}`}
              onClick={() => setAssetFilter(a)}
            >
              {a === "all" ? "TOUS ACTIFS" : a}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="empty-signals">
          <div className="empty-icon">◎</div>
          <p>Aucun signal pour ce filtre</p>
        </div>
      ) : (
        <div className="history-table-wrap">
          <table className="history-table">
            <thead>
              <tr>
                <th>ACTIF</th>
                <th>DIR.</th>
                <th>ENTRÉE</th>
                <th>SL</th>
                <th>TP</th>
                <th>RR</th>
                <th>CONF.</th>
                <th>DATE</th>
                <th>RÉSULTAT</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((s) => (
                <tr key={s.id} className="history-row" onClick={() => onSignalClick(s)}>
                  <td><span className="asset-badge sm">{s.symbol}</span></td>
                  <td><span className={`dir-badge sm ${s.direction === "BUY" ? "buy" : "sell"}`}>{s.direction}</span></td>
                  <td className="mono">{s.entry_price}</td>
                  <td className="mono sl-color">{s.stop_loss}</td>
                  <td className="mono tp-color">{s.take_profit}</td>
                  <td className="mono accent-blue">{s.risk_reward}:1</td>
                  <td>
                    <div className="mini-conf">
                      <div className="mini-conf-bar" style={{ width: `${s.confidence}%` }}></div>
                      <span>{s.confidence}%</span>
                    </div>
                  </td>
                  <td className="date-cell">
                    {new Date(s.created_at).toLocaleString("fr-FR", {
                      day: "2-digit", month: "2-digit",
                      hour: "2-digit", minute: "2-digit",
                    })}
                  </td>
                  <td>
                    <span className={`result-badge ${s.result || "active"}`}>
                      {s.result === "win" ? "WIN ✓" : s.result === "loss" ? "LOSS ✗" : s.result === "cancelled" ? "ANNULÉ" : "ACTIF"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
