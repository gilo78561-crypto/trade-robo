export default function BullLogo({ size = 48 }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Body */}
      <ellipse cx="50" cy="62" rx="28" ry="22" fill="#c41e3a" />
      {/* Head */}
      <ellipse cx="50" cy="40" rx="20" ry="18" fill="#c41e3a" />
      {/* Left horn */}
      <path d="M34 28 Q22 10 28 6 Q36 14 38 26" fill="#e8c84a" />
      {/* Right horn */}
      <path d="M66 28 Q78 10 72 6 Q64 14 62 26" fill="#e8c84a" />
      {/* Eyes */}
      <circle cx="43" cy="37" r="3.5" fill="#111" />
      <circle cx="57" cy="37" r="3.5" fill="#111" />
      <circle cx="44" cy="36" r="1.2" fill="#fff" />
      <circle cx="58" cy="36" r="1.2" fill="#fff" />
      {/* Nose */}
      <ellipse cx="50" cy="46" rx="9" ry="6" fill="#a01830" />
      <circle cx="46" cy="46" r="2.5" fill="#111" />
      <circle cx="54" cy="46" r="2.5" fill="#111" />
      {/* Ears */}
      <ellipse cx="31" cy="34" rx="6" ry="8" fill="#c41e3a" transform="rotate(-20 31 34)" />
      <ellipse cx="69" cy="34" rx="6" ry="8" fill="#c41e3a" transform="rotate(20 69 34)" />
      <ellipse cx="31" cy="34" rx="3.5" ry="5" fill="#a01830" transform="rotate(-20 31 34)" />
      <ellipse cx="69" cy="34" rx="3.5" ry="5" fill="#a01830" transform="rotate(20 69 34)" />
      {/* Ring */}
      <circle cx="50" cy="48" r="4" fill="none" stroke="#e8c84a" strokeWidth="1.8" />
      {/* Front legs */}
      <rect x="36" y="80" width="9" height="16" rx="3" fill="#a01830" />
      <rect x="55" y="80" width="9" height="16" rx="3" fill="#a01830" />
      {/* Hooves */}
      <rect x="35" y="93" width="11" height="5" rx="2" fill="#111" />
      <rect x="54" y="93" width="11" height="5" rx="2" fill="#111" />
      {/* Tail */}
      <path d="M78 62 Q90 58 88 72 Q86 80 80 78" fill="none" stroke="#c41e3a" strokeWidth="4" strokeLinecap="round" />
      <path d="M80 78 Q82 82 78 84" fill="none" stroke="#a01830" strokeWidth="3" strokeLinecap="round" />
      {/* Bull up arrow subtile */}
      <path d="M50 55 L50 68 M46 59 L50 55 L54 59" fill="none" stroke="#e8c84a" strokeWidth="1.5" strokeLinecap="round" opacity="0.7" />
    </svg>
  );
}
