// DataService.js
// Fetches real OHLCV data from multiple free APIs

const BINANCE_BASE = "https://api.binance.com/api/v3";
const YAHOO_BASE = "https://query1.finance.yahoo.com/v8/finance/chart";

const TF_MAP = {
  h4: { binance: "4h", minutes: 240, limit: 100 },
  h1: { binance: "1h", minutes: 60, limit: 100 },
  m15: { binance: "15m", minutes: 15, limit: 100 },
  m5: { binance: "5m", minutes: 5, limit: 100 },
};

const ASSET_MAP = {
  BTCUSD: { binance: "BTCUSDT", yahoo: "BTC-USD", type: "crypto" },
  XAUUSD: { binance: null, yahoo: "GC=F", type: "metal" },
  EURUSD: { binance: null, yahoo: "EURUSD=X", type: "forex" },
};

// Convert candle array to OHLCV objects
function parseCandle(c, type = "binance") {
  if (type === "binance") {
    return {
      timestamp: c[0],
      open: parseFloat(c[1]),
      high: parseFloat(c[2]),
      low: parseFloat(c[3]),
      close: parseFloat(c[4]),
      volume: parseFloat(c[5]),
    };
  }
  return c;
}

// Fetch from Binance API
async function fetchBinance(symbol, interval, limit = 100) {
  const url = `${BINANCE_BASE}/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`;
  const resp = await fetch(url);
  if (!resp.ok) throw new Error(`Binance ${resp.status}`);
  const data = await resp.json();
  return data.map((c) => parseCandle(c, "binance"));
}

// Fetch from Yahoo Finance via CORS proxy
async function fetchYahoo(symbol, interval, period = "5d") {
  const yahooIntervalMap = {
    "4h": { interval: "1h", range: "5d" },
    "1h": { interval: "1h", range: "5d" },
    "15m": { interval: "15m", range: "2d" },
    "5m": { interval: "5m", range: "1d" },
  };

  const cfg = yahooIntervalMap[interval] || { interval, range: period };
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(
    symbol
  )}?interval=${cfg.interval}&range=${cfg.range}`;

  // Use allorigins as CORS proxy for Yahoo
  const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(url)}`;

  try {
    const resp = await fetch(proxyUrl);
    const wrapper = await resp.json();
    const raw = JSON.parse(wrapper.contents);
    const result = raw.chart?.result?.[0];
    if (!result) throw new Error("No data from Yahoo");

    const timestamps = result.timestamp;
    const ohlcv = result.indicators.quote[0];
    const candles = [];

    for (let i = 0; i < timestamps.length; i++) {
      if (
        ohlcv.open[i] == null ||
        ohlcv.high[i] == null ||
        ohlcv.low[i] == null ||
        ohlcv.close[i] == null
      )
        continue;
      candles.push({
        timestamp: timestamps[i] * 1000,
        open: ohlcv.open[i],
        high: ohlcv.high[i],
        low: ohlcv.low[i],
        close: ohlcv.close[i],
        volume: ohlcv.volume?.[i] || 0,
      });
    }

    // For H4, aggregate 1h candles into 4h
    if (interval === "4h" && cfg.interval === "1h") {
      return aggregateCandles(candles, 4);
    }

    return candles;
  } catch (e) {
    throw new Error(`Yahoo ${symbol}: ${e.message}`);
  }
}

// Aggregate candles (e.g. 1h → 4h)
function aggregateCandles(candles, groupSize) {
  const result = [];
  for (let i = 0; i < candles.length; i += groupSize) {
    const group = candles.slice(i, i + groupSize);
    if (group.length === 0) continue;
    result.push({
      timestamp: group[0].timestamp,
      open: group[0].open,
      high: Math.max(...group.map((c) => c.high)),
      low: Math.min(...group.map((c) => c.low)),
      close: group[group.length - 1].close,
      volume: group.reduce((s, c) => s + c.volume, 0),
    });
  }
  return result;
}

// Generate realistic demo candles if API fails
function generateDemoCandles(asset, tf, count = 100) {
  const basePrice = { BTCUSD: 67000, XAUUSD: 3340, EURUSD: 1.085 };
  const volatility = { BTCUSD: 0.012, XAUUSD: 0.004, EURUSD: 0.0008 };
  const base = basePrice[asset] || 100;
  const vol = volatility[asset] || 0.01;
  const tfMinutes = TF_MAP[tf]?.minutes || 5;
  const now = Date.now();
  const candles = [];
  let price = base;

  for (let i = count - 1; i >= 0; i--) {
    const timestamp = now - i * tfMinutes * 60 * 1000;
    const change = price * vol * (Math.random() - 0.48);
    const open = price;
    price = open + change;
    const high = Math.max(open, price) + Math.abs(change) * Math.random() * 0.5;
    const low = Math.min(open, price) - Math.abs(change) * Math.random() * 0.5;
    candles.push({
      timestamp,
      open: parseFloat(open.toFixed(asset === "EURUSD" ? 5 : 2)),
      high: parseFloat(high.toFixed(asset === "EURUSD" ? 5 : 2)),
      low: parseFloat(low.toFixed(asset === "EURUSD" ? 5 : 2)),
      close: parseFloat(price.toFixed(asset === "EURUSD" ? 5 : 2)),
      volume: Math.floor(Math.random() * 1000 + 100),
      isDemo: true,
    });
  }
  return candles;
}

// Main fetch function with fallback
async function fetchCandles(asset, tf) {
  const assetInfo = ASSET_MAP[asset];
  const tfInfo = TF_MAP[tf];
  if (!assetInfo || !tfInfo) throw new Error(`Unknown asset/tf: ${asset}/${tf}`);

  try {
    // Crypto: use Binance
    if (assetInfo.type === "crypto" && assetInfo.binance) {
      return await fetchBinance(assetInfo.binance, tfInfo.binance, tfInfo.limit);
    }

    // Forex/Metals: use Yahoo Finance
    if (assetInfo.yahoo) {
      return await fetchYahoo(assetInfo.yahoo, tfInfo.binance);
    }
  } catch (e) {
    console.warn(`API failed for ${asset}/${tf}, using demo data: ${e.message}`);
  }

  // Fallback: demo data
  return generateDemoCandles(asset, tf, 100);
}

export const DataService = {
  async fetchAllTimeframes(asset) {
    const [h4, h1, m15, m5] = await Promise.all([
      fetchCandles(asset, "h4").catch(() => generateDemoCandles(asset, "h4")),
      fetchCandles(asset, "h1").catch(() => generateDemoCandles(asset, "h1")),
      fetchCandles(asset, "m15").catch(() => generateDemoCandles(asset, "m15")),
      fetchCandles(asset, "m5").catch(() => generateDemoCandles(asset, "m5")),
    ]);
    return { h4, h1, m15, m5 };
  },

  generateDemoCandles,
};
