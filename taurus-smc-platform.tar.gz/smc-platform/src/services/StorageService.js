// StorageService.js
const SIGNALS_KEY = "taurus_signals";
const SETTINGS_KEY = "taurus_settings";

const DEFAULT_SETTINGS = {
  enabledAssets: { XAUUSD: true, BTCUSD: true, EURUSD: true },
  minRR: 2,
  slMargin: 0.002,
  analysisFrequency: 5,
  enableBuy: true,
  enableSell: true,
  telegramToken: "",
  telegramChatId: "",
};

export const StorageService = {
  getSignals() {
    try {
      const raw = localStorage.getItem(SIGNALS_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  },

  addSignals(newSignals) {
    const existing = this.getSignals();
    const filtered = newSignals.filter((ns) => {
      const recent = existing.find(
        (e) =>
          e.symbol === ns.symbol &&
          e.direction === ns.direction &&
          Math.abs(new Date(e.created_at) - new Date(ns.created_at)) < 15 * 60 * 1000
      );
      return !recent;
    });

    const all = [...filtered, ...existing].slice(0, 1000);
    localStorage.setItem(SIGNALS_KEY, JSON.stringify(all));
    return all;
  },

  updateSignalResult(id, result) {
    const signals = this.getSignals();
    const updated = signals.map((s) =>
      s.id === id
        ? {
            ...s,
            result,
            status: result === "win" || result === "loss" ? "closed" : s.status,
            closed_at: new Date().toISOString(),
          }
        : s
    );
    localStorage.setItem(SIGNALS_KEY, JSON.stringify(updated));
    return updated;
  },

  getSettings() {
    try {
      const raw = localStorage.getItem(SETTINGS_KEY);
      return raw ? { ...DEFAULT_SETTINGS, ...JSON.parse(raw) } : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  },

  saveSettings(settings) {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  },
};
