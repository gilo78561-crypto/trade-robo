// SMCEngine.js — Full SMC/ICT analysis logic

function highestHigh(candles) {
  return Math.max(...candles.map((c) => c.high));
}
function lowestLow(candles) {
  return Math.min(...candles.map((c) => c.low));
}
function isSwingHigh(candles, i, lookback = 3) {
  if (i < lookback || i >= candles.length - lookback) return false;
  const mid = candles[i].high;
  for (let j = i - lookback; j <= i + lookback; j++) {
    if (j === i) continue;
    if (candles[j].high >= mid) return false;
  }
  return true;
}
function isSwingLow(candles, i, lookback = 3) {
  if (i < lookback || i >= candles.length - lookback) return false;
  const mid = candles[i].low;
  for (let j = i - lookback; j <= i + lookback; j++) {
    if (j === i) continue;
    if (candles[j].low <= mid) return false;
  }
  return true;
}

function getSwingPoints(candles, lookback = 3) {
  const highs = [];
  const lows = [];
  for (let i = lookback; i < candles.length - lookback; i++) {
    if (isSwingHigh(candles, i, lookback)) highs.push({ idx: i, price: candles[i].high });
    if (isSwingLow(candles, i, lookback)) lows.push({ idx: i, price: candles[i].low });
  }
  return { highs, lows };
}

// Detect HTF Bias (H4)
function detectHTFBias(h4) {
  if (!h4 || h4.length < 20) return null;
  const recent = h4.slice(-40);
  const { highs, lows } = getSwingPoints(recent, 3);

  if (highs.length < 2 || lows.length < 2) return null;

  const lastHH = highs[highs.length - 1].price;
  const prevHH = highs[highs.length - 2].price;
  const lastHL = lows[lows.length - 1].price;
  const prevHL = lows[lows.length - 2].price;

  // Bullish: Higher Highs + Higher Lows
  if (lastHH > prevHH && lastHL > prevHL) {
    return { bias: "bullish", reason: "HH + HL confirmés" };
  }
  // Bearish: Lower Highs + Lower Lows
  if (lastHH < prevHH && lastHL < prevHL) {
    return { bias: "bearish", reason: "LH + LL confirmés" };
  }

  // BOS detection on H4
  const lastClose = h4[h4.length - 1].close;
  const recentHighs = highs.slice(-3).map((h) => h.price);
  const recentLows = lows.slice(-3).map((l) => l.price);
  const prevHigh = recentHighs[recentHighs.length - 2] || 0;
  const prevLow = recentLows[recentLows.length - 2] || Infinity;

  if (lastClose > prevHigh) return { bias: "bullish", reason: "BOS haussier H4" };
  if (lastClose < prevLow) return { bias: "bearish", reason: "BOS baissier H4" };

  return null;
}

// Detect liquidity sweep
function detectLiquiditySweep(candles, direction) {
  if (!candles || candles.length < 20) return null;
  const recent = candles.slice(-60);

  if (direction === "buy") {
    // Looking for sell-side liquidity (equal lows / recent lows swept)
    const { lows } = getSwingPoints(recent, 2);
    if (lows.length < 2) return null;
    const significantLow = lows[lows.length - 2]?.price;
    if (!significantLow) return null;

    // Check if price swept below and closed above
    const last = recent[recent.length - 1];
    const prev = recent[recent.length - 2];

    const swept = prev.low < significantLow || last.low < significantLow;
    const recovered = last.close > significantLow;

    if (swept && recovered) {
      return {
        taken: true,
        level: significantLow,
        type: "Sell-Side Liquidity",
        sweepLow: Math.min(prev.low, last.low),
      };
    }
  }

  if (direction === "sell") {
    // Buy-side liquidity (equal highs / recent highs swept)
    const { highs } = getSwingPoints(recent, 2);
    if (highs.length < 2) return null;
    const significantHigh = highs[highs.length - 2]?.price;
    if (!significantHigh) return null;

    const last = recent[recent.length - 1];
    const prev = recent[recent.length - 2];

    const swept = prev.high > significantHigh || last.high > significantHigh;
    const rejected = last.close < significantHigh;

    if (swept && rejected) {
      return {
        taken: true,
        level: significantHigh,
        type: "Buy-Side Liquidity",
        sweepHigh: Math.max(prev.high, last.high),
      };
    }
  }

  return null;
}

// Detect CHOCH (Change of Character)
function detectCHOCH(candles, direction) {
  if (!candles || candles.length < 20) return null;
  const recent = candles.slice(-50);
  const { highs, lows } = getSwingPoints(recent, 2);

  if (direction === "buy") {
    // Bullish CHOCH: breaks the last Lower High
    if (highs.length < 2) return null;
    const lastLH = highs[highs.length - 2]?.price;
    const currentClose = recent[recent.length - 1].close;
    if (lastLH && currentClose > lastLH) {
      return {
        detected: true,
        level: lastLH,
        type: "Bullish CHOCH",
        idx: recent.length - 1,
      };
    }
  }

  if (direction === "sell") {
    // Bearish CHOCH: breaks the last Higher Low
    if (lows.length < 2) return null;
    const lastHL = lows[lows.length - 2]?.price;
    const currentClose = recent[recent.length - 1].close;
    if (lastHL && currentClose < lastHL) {
      return {
        detected: true,
        level: lastHL,
        type: "Bearish CHOCH",
        idx: recent.length - 1,
      };
    }
  }

  return null;
}

// Detect Order Block
function detectOrderBlock(candles, choch, direction) {
  if (!candles || !choch || candles.length < 10) return null;
  const recent = candles.slice(-40);

  if (direction === "buy") {
    // Last bearish candle before bullish impulse (CHOCH)
    for (let i = recent.length - 3; i >= recent.length - 15; i--) {
      if (i < 0) break;
      const c = recent[i];
      const isBearish = c.close < c.open;
      const nextImpulse =
        i + 2 < recent.length && recent[i + 2].close > recent[i + 1].close;

      if (isBearish && nextImpulse) {
        const mitigated = recent
          .slice(i + 1)
          .some((later) => later.low <= c.close);
        if (!mitigated) {
          return {
            found: true,
            high: c.high,
            low: c.low,
            midpoint: (c.high + c.low) / 2,
            candleIdx: i,
            type: "Bullish OB",
          };
        }
      }
    }
  }

  if (direction === "sell") {
    // Last bullish candle before bearish impulse (CHOCH)
    for (let i = recent.length - 3; i >= recent.length - 15; i--) {
      if (i < 0) break;
      const c = recent[i];
      const isBullish = c.close > c.open;
      const nextImpulse =
        i + 2 < recent.length && recent[i + 2].close < recent[i + 1].close;

      if (isBullish && nextImpulse) {
        const mitigated = recent
          .slice(i + 1)
          .some((later) => later.high >= c.close);
        if (!mitigated) {
          return {
            found: true,
            high: c.high,
            low: c.low,
            midpoint: (c.high + c.low) / 2,
            candleIdx: i,
            type: "Bearish OB",
          };
        }
      }
    }
  }

  return null;
}

// Detect Fair Value Gap
function detectFVG(candles, direction) {
  if (!candles || candles.length < 5) return null;
  const recent = candles.slice(-30);

  for (let i = recent.length - 3; i >= recent.length - 15; i--) {
    if (i < 1 || i + 1 >= recent.length) continue;
    const c1 = recent[i - 1];
    const c2 = recent[i];
    const c3 = recent[i + 1];

    if (direction === "buy") {
      // Bullish FVG: c1.high < c3.low (gap between candle 1 high and candle 3 low)
      if (c1.high < c3.low && c2.close > c2.open) {
        const fvgLow = c1.high;
        const fvgHigh = c3.low;
        const currentPrice = recent[recent.length - 1].close;
        if (currentPrice >= fvgLow && currentPrice <= fvgHigh * 1.01) {
          return { found: true, high: fvgHigh, low: fvgLow, type: "Bullish FVG", size: fvgHigh - fvgLow };
        }
        if (currentPrice > fvgHigh * 0.998) {
          return { found: true, high: fvgHigh, low: fvgLow, type: "Bullish FVG (proche)", size: fvgHigh - fvgLow };
        }
      }
    }

    if (direction === "sell") {
      // Bearish FVG: c1.low > c3.high
      if (c1.low > c3.high && c2.close < c2.open) {
        const fvgHigh = c1.low;
        const fvgLow = c3.high;
        const currentPrice = recent[recent.length - 1].close;
        if (currentPrice <= fvgHigh && currentPrice >= fvgLow * 0.99) {
          return { found: true, high: fvgHigh, low: fvgLow, type: "Bearish FVG", size: fvgHigh - fvgLow };
        }
        if (currentPrice < fvgHigh * 1.002) {
          return { found: true, high: fvgHigh, low: fvgLow, type: "Bearish FVG (proche)", size: fvgHigh - fvgLow };
        }
      }
    }
  }

  return null;
}

// Fibonacci discount/premium zones
function calcFibZone(candles, direction) {
  if (!candles || candles.length < 20) return null;
  const recent = candles.slice(-40);
  const swingHigh = highestHigh(recent);
  const swingLow = lowestLow(recent);
  const range = swingHigh - swingLow;
  const currentPrice = recent[recent.length - 1].close;
  const fibPct = ((currentPrice - swingLow) / range) * 100;

  if (direction === "buy") {
    const inDiscount = fibPct < 50;
    const inOB = fibPct >= 21 && fibPct <= 38; // OTE zone
    return {
      inDiscount,
      inOTE: inOB,
      fibPct: parseFloat(fibPct.toFixed(1)),
      swingHigh,
      swingLow,
      label: inOB ? "Zone OTE (62-79%)" : inDiscount ? "Zone Discount" : "Zone Premium",
    };
  }

  if (direction === "sell") {
    const inPremium = fibPct > 50;
    const inOTE = fibPct >= 62 && fibPct <= 79;
    return {
      inPremium,
      inOTE,
      fibPct: parseFloat(fibPct.toFixed(1)),
      swingHigh,
      swingLow,
      label: inOTE ? "Zone OTE Premium (62-79%)" : inPremium ? "Zone Premium" : "Zone Discount",
    };
  }

  return null;
}

// Detect BOS on H1
function detectBOS(h1, direction) {
  if (!h1 || h1.length < 20) return null;
  const recent = h1.slice(-40);
  const { highs, lows } = getSwingPoints(recent, 3);

  if (direction === "buy") {
    if (highs.length < 2) return null;
    const lastSwingHigh = highs[highs.length - 2]?.price;
    const currentClose = recent[recent.length - 1].close;
    if (lastSwingHigh && currentClose > lastSwingHigh) {
      return { detected: true, level: lastSwingHigh, type: "BOS Haussier H1" };
    }
  }

  if (direction === "sell") {
    if (lows.length < 2) return null;
    const lastSwingLow = lows[lows.length - 2]?.price;
    const currentClose = recent[recent.length - 1].close;
    if (lastSwingLow && currentClose < lastSwingLow) {
      return { detected: true, level: lastSwingLow, type: "BOS Baissier H1" };
    }
  }

  return null;
}

// Get take profit target
function getTPTarget(candles, direction, entryPrice) {
  if (!candles || candles.length < 10) return null;
  const recent = candles.slice(-60);
  const { highs, lows } = getSwingPoints(recent, 2);

  if (direction === "buy") {
    // Buy-side liquidity: equal highs, recent swing highs
    const candidates = highs.filter((h) => h.price > entryPrice).map((h) => h.price);
    if (candidates.length > 0) return Math.min(...candidates);
    return highestHigh(recent);
  }

  if (direction === "sell") {
    // Sell-side liquidity: equal lows, recent swing lows
    const candidates = lows.filter((l) => l.price < entryPrice).map((l) => l.price);
    if (candidates.length > 0) return Math.max(...candidates);
    return lowestLow(recent);
  }

  return null;
}

// Main analysis function
export class SMCEngine {
  constructor(data, settings = {}) {
    this.data = data;
    this.settings = settings;
    this.minRR = settings.minRR || 2;
    this.slMargin = settings.slMargin || 0.002;
  }

  analyze(asset) {
    const { h4, h1, m15, m5 } = this.data;
    if (!h4 || !h1 || !m15 || !m5) return null;

    // Try BUY
    if (this.settings.enableBuy !== false) {
      const buySignal = this.analyzeBuy(asset, h4, h1, m15, m5);
      if (buySignal) return buySignal;
    }

    // Try SELL
    if (this.settings.enableSell !== false) {
      const sellSignal = this.analyzeSell(asset, h4, h1, m15, m5);
      if (sellSignal) return sellSignal;
    }

    return null;
  }

  analyzeBuy(asset, h4, h1, m15, m5) {
    const confluences = [];
    let confidence = 0;

    // Step 1: HTF Bias
    const htfBias = detectHTFBias(h4);
    if (!htfBias || htfBias.bias !== "bullish") return null;
    confluences.push(`✓ Biais HTF Haussier (${htfBias.reason})`);
    confidence += 20;

    // Step 2: Sell-Side Liquidity taken
    const liquidity = detectLiquiditySweep(m15, "buy");
    if (!liquidity?.taken) return null;
    confluences.push(`✓ Liquidité vendeuse prise (${liquidity.type})`);
    confidence += 20;

    // Step 3: Bullish CHOCH
    const choch = detectCHOCH(m15, "buy");
    if (!choch?.detected) return null;
    confluences.push(`✓ CHOCH Haussier détecté (${choch.level?.toFixed(4)})`);
    confidence += 20;

    // Step 4: BOS on H1
    const bos = detectBOS(h1, "buy");
    if (bos?.detected) {
      confluences.push(`✓ BOS Haussier H1 (${bos.level?.toFixed(4)})`);
      confidence += 10;
    }

    // Step 5: Order Block
    const ob = detectOrderBlock(m15, choch, "buy");
    if (!ob?.found) return null;
    confluences.push(`✓ Order Block Haussier [${ob.low?.toFixed(4)} - ${ob.high?.toFixed(4)}]`);
    confidence += 15;

    // Step 6: FVG
    const fvg = detectFVG(m5, "buy");
    if (fvg?.found) {
      confluences.push(`✓ Fair Value Gap Haussier [${fvg.low?.toFixed(4)} - ${fvg.high?.toFixed(4)}]`);
      confidence += 10;
    }

    // Step 7: Fibonacci Zone
    const fibZone = calcFibZone(m15, "buy");
    if (fibZone) {
      if (fibZone.inDiscount) {
        confluences.push(`✓ Zone Discount Fibonacci (${fibZone.fibPct}%)`);
        confidence += fibZone.inOTE ? 10 : 5;
      } else {
        confluences.push(`⚠ Zone Premium (${fibZone.fibPct}%) - sous-optimal`);
        confidence -= 5;
      }
    }

    // Entry price: OB midpoint or current price
    const currentPrice = m5[m5.length - 1].close;
    const entryPrice = ob ? (ob.low + ob.high) / 2 : currentPrice;

    // Stop Loss: below the sweep
    const sweepLow = liquidity.sweepLow || (ob ? ob.low : currentPrice);
    const slDistance = sweepLow * this.slMargin;
    const stopLoss = parseFloat((sweepLow - slDistance).toFixed(decimals(asset)));

    // Take Profit
    const tpTarget = getTPTarget(m15, "buy", entryPrice);
    const takeProfit = tpTarget
      ? parseFloat(tpTarget.toFixed(decimals(asset)))
      : parseFloat((entryPrice + (entryPrice - stopLoss) * this.minRR).toFixed(decimals(asset)));

    const risk = entryPrice - stopLoss;
    const reward = takeProfit - entryPrice;
    const rr = parseFloat((reward / risk).toFixed(2));

    if (rr < this.minRR) return null;

    confidence = Math.min(100, confidence);

    return {
      id: `${asset}-BUY-${Date.now()}`,
      symbol: asset,
      direction: "BUY",
      entry_price: parseFloat(entryPrice.toFixed(decimals(asset))),
      stop_loss: stopLoss,
      take_profit: takeProfit,
      risk_reward: rr,
      timeframe: "M5",
      status: "active",
      confidence,
      created_at: new Date().toISOString(),
      result: null,
      analysis: {
        htf_bias: "bullish",
        htf_reason: htfBias.reason,
        liquidity_type: liquidity.type,
        liquidity_level: liquidity.level,
        choch_detected: choch.detected,
        choch_level: choch.level,
        bos_detected: bos?.detected || false,
        bos_level: bos?.level,
        order_block_high: ob?.high,
        order_block_low: ob?.low,
        fvg_start: fvg?.low,
        fvg_end: fvg?.high,
        fib_zone: fibZone?.label,
        fib_pct: fibZone?.fibPct,
        confluences,
        reason: confluences.join(" | "),
      },
    };
  }

  analyzeSell(asset, h4, h1, m15, m5) {
    const confluences = [];
    let confidence = 0;

    // Step 1: HTF Bias bearish
    const htfBias = detectHTFBias(h4);
    if (!htfBias || htfBias.bias !== "bearish") return null;
    confluences.push(`✓ Biais HTF Baissier (${htfBias.reason})`);
    confidence += 20;

    // Step 2: Buy-Side Liquidity taken
    const liquidity = detectLiquiditySweep(m15, "sell");
    if (!liquidity?.taken) return null;
    confluences.push(`✓ Liquidité acheteuse prise (${liquidity.type})`);
    confidence += 20;

    // Step 3: Bearish CHOCH
    const choch = detectCHOCH(m15, "sell");
    if (!choch?.detected) return null;
    confluences.push(`✓ CHOCH Baissier détecté (${choch.level?.toFixed(4)})`);
    confidence += 20;

    // Step 4: BOS on H1
    const bos = detectBOS(h1, "sell");
    if (bos?.detected) {
      confluences.push(`✓ BOS Baissier H1 (${bos.level?.toFixed(4)})`);
      confidence += 10;
    }

    // Step 5: Order Block
    const ob = detectOrderBlock(m15, choch, "sell");
    if (!ob?.found) return null;
    confluences.push(`✓ Order Block Baissier [${ob.low?.toFixed(4)} - ${ob.high?.toFixed(4)}]`);
    confidence += 15;

    // Step 6: FVG
    const fvg = detectFVG(m5, "sell");
    if (fvg?.found) {
      confluences.push(`✓ Fair Value Gap Baissier [${fvg.low?.toFixed(4)} - ${fvg.high?.toFixed(4)}]`);
      confidence += 10;
    }

    // Step 7: Fibonacci Zone
    const fibZone = calcFibZone(m15, "sell");
    if (fibZone) {
      if (fibZone.inPremium) {
        confluences.push(`✓ Zone Premium Fibonacci (${fibZone.fibPct}%)`);
        confidence += fibZone.inOTE ? 10 : 5;
      }
    }

    const currentPrice = m5[m5.length - 1].close;
    const entryPrice = ob ? (ob.low + ob.high) / 2 : currentPrice;

    const sweepHigh = liquidity.sweepHigh || (ob ? ob.high : currentPrice);
    const slDistance = sweepHigh * this.slMargin;
    const stopLoss = parseFloat((sweepHigh + slDistance).toFixed(decimals(asset)));

    const tpTarget = getTPTarget(m15, "sell", entryPrice);
    const takeProfit = tpTarget
      ? parseFloat(tpTarget.toFixed(decimals(asset)))
      : parseFloat((entryPrice - (stopLoss - entryPrice) * this.minRR).toFixed(decimals(asset)));

    const risk = stopLoss - entryPrice;
    const reward = entryPrice - takeProfit;
    const rr = parseFloat((reward / risk).toFixed(2));

    if (rr < this.minRR) return null;

    confidence = Math.min(100, confidence);

    return {
      id: `${asset}-SELL-${Date.now()}`,
      symbol: asset,
      direction: "SELL",
      entry_price: parseFloat(entryPrice.toFixed(decimals(asset))),
      stop_loss: stopLoss,
      take_profit: takeProfit,
      risk_reward: rr,
      timeframe: "M5",
      status: "active",
      confidence,
      created_at: new Date().toISOString(),
      result: null,
      analysis: {
        htf_bias: "bearish",
        htf_reason: htfBias.reason,
        liquidity_type: liquidity.type,
        liquidity_level: liquidity.level,
        choch_detected: choch.detected,
        choch_level: choch.level,
        bos_detected: bos?.detected || false,
        bos_level: bos?.level,
        order_block_high: ob?.high,
        order_block_low: ob?.low,
        fvg_start: fvg?.low,
        fvg_end: fvg?.high,
        fib_zone: fibZone?.label,
        fib_pct: fibZone?.fibPct,
        confluences,
        reason: confluences.join(" | "),
      },
    };
  }
}

function decimals(asset) {
  if (asset === "EURUSD") return 5;
  if (asset === "XAUUSD") return 2;
  if (asset === "BTCUSD") return 1;
  return 4;
}
