// NotificationService.js
export const NotificationService = {
  async sendTelegram(signal, settings) {
    const { telegramToken, telegramChatId } = settings;
    if (!telegramToken || !telegramChatId) return;

    const dir = signal.direction;
    const emoji = dir === "BUY" ? "🟢" : "🔴";
    const confluences = signal.analysis?.confluences?.join("\n") || "";

    const message = `${emoji} <b>${signal.symbol} ${dir}</b>

💰 Entrée : <code>${signal.entry_price}</code>
🛑 SL : <code>${signal.stop_loss}</code>
🎯 TP : <code>${signal.take_profit}</code>
📊 RR : <b>${signal.risk_reward}:1</b>
⚡ Confiance : ${signal.confidence}%

<b>Confluences :</b>
${confluences}

⏱ ${new Date(signal.created_at).toLocaleString("fr-FR")}

⚠️ <i>Outil d'aide à la décision uniquement</i>`;

    try {
      await fetch(
        `https://api.telegram.org/bot${telegramToken}/sendMessage`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            chat_id: telegramChatId,
            text: message,
            parse_mode: "HTML",
          }),
        }
      );
    } catch (e) {
      console.error("Telegram error:", e);
    }
  },
};
